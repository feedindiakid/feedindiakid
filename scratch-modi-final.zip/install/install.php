<?php
function displayMessage($message, $type) {
    $color = ($type === 'error') ? 'red' : 'green';
    return "<div style='background-color: #f8d7da; color: $color; padding: 15px; border-radius: 8px; margin: 10px 0;'>
                <strong>Status:</strong> $message
            </div>";
}

$admin_token = file_get_contents('../admin/token.txt');
$shost = file_get_contents('../admin/shost.txt');
$user = isset($_REQUEST['user']) ? htmlspecialchars($_REQUEST['user']) : '';
$token = isset($_REQUEST['token']) ? htmlspecialchars($_REQUEST['token']) : '';
$shost = isset($_REQUEST['shost']) ? htmlspecialchars($_REQUEST['shost']) : '';


if (!empty($admin_token)) {
    echo displayMessage("Admin User ID Alredy Created. <a href='/admin'>[ Go To Admin Mode ]</a>", 'error');
} elseif (empty($user) || empty($token)) {
    echo displayMessage("Something went wrong! Please try <a href=''>[Re-Genarate]</a>", 'error');
} else {
    $fp = fopen("../admin/token.txt", "w+");
    fwrite($fp, "$token");
    fclose($fp);
     $fp = fopen("../admin/shost.txt", "w+");
    fwrite($fp, "$shost");
    fclose($fp);
    // Display values in a nice UI
    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Information</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                width: 350px;
                text-align: center;
            }
            h1 {
                margin-bottom: 20px;
                color: #333;
            }
            .info-card {
                background: #e9ecef;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }
            .info {
                margin: 10px 0;
                font-size: 18px;
                color: #555;
            }
            strong {
                color: #333;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>User M-PIN Details</h1>
            <div class="info-card">
                <div class="info">
                    <strong>M-PIN : </strong>
                    <span>' . $user . '</span>
                </div>
                
                
            </div>
        </div>
    </body>
    </html>
    ';
}
?>
