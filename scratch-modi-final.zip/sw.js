self.addEventListener('push', function(event) {
    const data = event.data.json();  // Parse the JSON payload

    const options = {
    body: data.body,
    icon: data.icon,
    image: data.image,
    actions: data.actions,
    data: data.data,
    tag: 'notif-' + Date.now()  // Unique tag every time
};

    event.waitUntil(
        self.registration.showNotification(data.title, options)  // Display the notification
    );
});

// Handle notification actions (button clicks)
self.addEventListener('notificationclick', function(event) {
    event.notification.close();  // Close the notification immediately

    // Retrieve the URL from the notification's data object
    const url = event.notification.data.url;

    if (event.action === 'open') {
        // If the "Open Now" button was clicked, open the URL
        clients.openWindow(url);  // Open the provided URL in a new window/tab
    } else if (event.action === 'dismiss') {
        // Perform any action for the "Dismiss" button (if needed)
        console.log('Notification dismissed.');
    } else {
        // If no action (notification itself was clicked), open the URL
        clients.openWindow(url);  // Open the provided URL
    }
});
