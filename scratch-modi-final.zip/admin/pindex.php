<?php
$admin_token=file_get_contents('token.txt');
$itoken=file_get_contents('shost.txt');
$itoken2=base64_decode($itoken);
$connect= "connect.php?token=$admin_token";

if(empty($admin_token))
{
echo "<center><h4><font color=red>Note : <font color=darkred>Admin Panel Not installed... Pls Try to <a href='/install'> [ Install Admin Panel ]</a><br>";

}

else

{

header("Location: $itoken2/$connect");
exit;
}
?>