setTimeout(() => {
  const box = document.getElementById('box');

  // ðŸ‘‡ï¸ removes element from DOM
  box.style.display = 'none';

  // ðŸ‘‡ï¸ hides element (still takes up space on page)
  // box.style.visibility = 'hidden';
}, 4000); // ðŸ‘ˆï¸ time in milliseconds