

<?php

error_reporting(1);
$amu = $_REQUEST['amount'];

$shost = file_exists('shost.txt') ? file_get_contents('shost.txt') : '';
$hosting = $_SERVER['SERVER_NAME'] ?? 'localhost';

$itoken = base64_decode("$shost") . base64_decode("YXBpLz8=");
$itok = base64_decode("$shost") . base64_decode("YXBpL3VwaS5waHA/");

// Suppress errors and check file existence
$admin_token = file_exists('token.txt') ? file_get_contents('token.txt') : '';
$info = file_exists('info.txt') ? file_get_contents('info.txt') : '';

$price = base64_decode($info);
$price = explode('=', $price);

// Check if the decoded price contains both values
$min_price = isset($price[0]) ? (int)$price[0] : 0;
$max_price = isset($price[1]) ? (int)$price[1] : 0;

$amt = rand($min_price, $max_price);

$data = "token=$admin_token&amount=$amu&host=$hosting";
$get_upi = "$itok$data";
$link = "$itoken$data";



header("Location: $link");





?>